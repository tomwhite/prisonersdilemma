package org.tiling.game.prisonersdilemma;

import org.tiling.game.*;

public interface PrisonersDilemmaMoves {

	public final static PrisonersDilemmaMove C = PrisonersDilemmaMove.C;
	public final static PrisonersDilemmaMove D = PrisonersDilemmaMove.D;



}