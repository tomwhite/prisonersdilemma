package org.tiling.game;

public class Move {

}